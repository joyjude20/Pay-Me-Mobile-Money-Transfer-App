// import 'dart:io';

// httpE() {
//   switch (HttpException) {
//     case SocketException:
//   }
// }
